const getHome = (req, res) => {
  res.render("home");
};

module.exports = { getHome };
