public interface Shape {
    String draw();
}
