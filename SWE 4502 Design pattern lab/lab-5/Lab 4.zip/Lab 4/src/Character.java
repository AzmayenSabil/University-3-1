public interface Character {

    public void create();
}
