public class Pikeman implements Enemy {

    @Override
    public void create() {
        System.out.print("Enemy with stick ");
    }

}