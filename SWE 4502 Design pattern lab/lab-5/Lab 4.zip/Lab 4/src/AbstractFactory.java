public abstract class AbstractFactory {

    Character c;
    public Character createElement()
    {
        return c;
    }
}
