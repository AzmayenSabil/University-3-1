public interface Enemy extends Character{

    public void create();
}